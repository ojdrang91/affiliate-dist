
const btn=document.querySelector('.menu-btn');
const nav=document.querySelector('.navlinks');
if(btn&&nav){btn.addEventListener('click',()=>{const o=nav.classList.toggle('open');btn.setAttribute('aria-expanded',o?'true':'false')})}
document.querySelectorAll('a[data-affiliate]').forEach(a=>{
  a.addEventListener('click',()=>{try{sessionStorage.setItem('lastAffiliateClick',new Date().toISOString())}catch(e){}})
});

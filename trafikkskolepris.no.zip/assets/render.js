(function(root){
const FEES = 480 + 1490;
const kr = n => n.toLocaleString('nb-NO').replace(/\u00a0|\u202f/g,' ') + ' kr';
function estimate(s, n){
  if(s.type==='itemized'){
    const base = s.items.reduce((a,[,v])=>a+v,0);
    return {total: base + n*s.lesson, lines:[...s.items, [n+' kjøretimer à '+kr(s.lesson), n*s.lesson]]};
  }
  if(s.type==='package'){
    let best=null;
    for(const p of s.packages){
      let total, lines;
      if(n<=p.lessons){ total=p.price; lines=[[p.label+' ('+p.lessons+' timer)',p.price]]; }
      else if(s.lesson){ const x=n-p.lessons; total=p.price+x*s.lesson; lines=[[p.label+' ('+p.lessons+' timer)',p.price],[x+' ekstra kjøretimer à '+kr(s.lesson),x*s.lesson]]; }
      else continue;
      if(s.adders){ for(const a of s.adders){ total+=a[1]; lines.push(a); } }
      if(!best||total<best.total) best={total,lines};
    }
    return best;
  }
  return null;
}
function renderCity(c, n, withFees){
  const fees = withFees ? FEES : 0;
  const ranked = c.schools.map(s=>({s, e:estimate(s,n)})).filter(x=>x.e).sort((a,b)=>a.e.total-b.e.total);
  const notCalc = c.schools.filter(s=>s.type!=='partial' && !estimate(s,n));
  const partial = c.schools.filter(s=>s.type==='partial');
  const totals = ranked.map(x=>x.e.total+fees);
  let summary;
  if(totals.length){
    const min=totals[0], mx=totals[totals.length-1];
    summary = `<div><span>Billigst</span><strong>${kr(min)}</strong><small>${ranked[0].s.name}</small></div>`+
      `<div><span>Dyrest</span><strong>${kr(mx)}</strong><small>${ranked[ranked.length-1].s.name}</small></div>`+
      `<div><span>Forskjell</span><strong>${kr(mx-min)}</strong><small>for ${n} kjøretimer${fees?' med gebyrer':''}</small></div>`;
  } else summary = `<div><span>Ingen skoler å regne på</span><strong>–</strong><small>Prøv et annet antall timer</small></div>`;
  const max = Math.max(...totals,1);
  const rank = ranked.map((x,i)=>{
    const t = x.e.total+fees, d = t-totals[0];
    const lines = x.e.lines.concat(fees?[['Gebyrer Statens vegvesen',FEES]]:[]);
    return `<li class="${i===0?'best':''}">
      <div class="row"><div class="pos">${i+1}</div>
        <div class="name"><h3>${x.s.name}<span class="badge">${x.s.type==='package'?'Pakkepris':'Full prisliste'}</span></h3>
          <div class="meta">${x.s.where}</div>
          <div class="track" aria-hidden="true"><i style="width:${Math.round(t/max*100)}%"></i></div></div>
        <div class="price"><strong>${kr(t)}</strong><span class="diff">${i===0?'Lavest totalpris':'+ '+kr(d)+' mer'}</span></div></div>
      <details class="more" data-school="${x.s.name}" data-pos="${i+1}"><summary>Se hva som er med</summary>
        <div class="breakdown"><div><table>${lines.map(([l,v])=>`<tr><td>${l}</td><td>${kr(v)}</td></tr>`).join('')}
            <tr class="total"><td>Totalt</td><td>${kr(t)}</td></tr></table>
            ${x.s.note?`<p class="note">${x.s.note}</p>`:''}
            ${x.s.src?`<p class="note"><a href="${x.s.src}" target="_blank" rel="noopener nofollow" data-school="${x.s.name}" data-pos="${i+1}" data-type="prisliste">Skolens prisliste</a></p>`:''}</div>
          <div class="reviews" data-place="${x.s.placeId||''}"><b>Google-vurdering</b>Vises her når siden kobles til Google Places API. Vurderingen påvirker ikke rekkefølgen.</div>
        </div></details></li>`;
  }).join('') + notCalc.map(s=>`<li><div class="row"><div class="pos">–</div>
      <div class="name"><h3>${s.name}<span class="badge">Pakkepris</span></h3><div class="meta">${s.where}</div></div>
      <div class="price"><span>Kan ikke regnes ut for ${n} timer. Skolen oppgir ikke pris på ekstra timer.</span></div></div></li>`).join('');
  const part = partial.map(s=>`<article><h3>${s.name}</h3><div class="note" style="margin:2px 0 0">${s.where}</div>
    ${s.known.length?`<ul>${s.known.map(([l,v])=>`<li><span>${l}</span><b>${kr(v)}</b></li>`).join('')}</ul>`:''}
    <p>${s.note||''}${s.src?` <a href="${s.src}" target="_blank" rel="noopener nofollow" data-school="${s.name}" data-pos="0" data-type="prisliste_delvis">Prisliste</a>`:''}</p></article>`).join('');
  return {summary, rank, partial:part, hasPartial:partial.length>0, ranked, totals};
}
root.HKL = {FEES, kr, estimate, renderCity};
if(typeof module!=='undefined') module.exports = root.HKL;
})(typeof window!=='undefined'?window:globalThis);

(function(){
  var city = document.body.dataset.city || 'forside';
  var t = window.tspTrack || function(){};

  /* Klikk til skolenes prislister (viktigste hendelse: viser interesse for en konkret skole) */
  document.addEventListener('click', function(e){
    var a = e.target.closest('a[data-school]');
    if(a){ t('school_click',{city:city, school:a.dataset.school, position:+a.dataset.pos||0, link_type:a.dataset.type||'prisliste', link_url:a.href}); return; }
    var c = e.target.closest('a[data-city-link]');
    if(c){ t('city_select',{from_city:city, to_city:c.dataset.cityLink}); }
  });
  /* Åpning av prisoppstilling */
  document.addEventListener('toggle', function(e){
    var d = e.target; if(!d.open || !d.dataset || !d.dataset.school) return;
    t(d.classList.contains('more') ? 'school_details_open' : 'faq_open', {city:city, school:d.dataset.school, position:+d.dataset.pos||0});
  }, true);

  if(!document.body.dataset.city) return;
  var c = window.HKL_DATA.CITIES[city];
  var h = document.getElementById('hours'), f = document.getElementById('fees');
  function draw(){
    var n = +h.value; document.getElementById('hoursOut').textContent = n;
    var r = HKL.renderCity(c, n, f.checked);
    document.getElementById('summary').innerHTML = r.summary;
    document.getElementById('rank').innerHTML = r.rank;
    document.getElementById('rankTitle').textContent = 'Totalpris klasse B i ' + c.name + ', ' + n + ' kjøretimer';
    return r;
  }
  function report(){
    var r = draw();
    t('calculator_change',{city:city, hours:+h.value, fees_included:f.checked, cheapest_school:r.ranked[0]?r.ranked[0].s.name:'', cheapest_total:r.totals[0]||0});
  }
  h.addEventListener('input', draw);
  h.addEventListener('change', report);
  f.addEventListener('change', report);
})();

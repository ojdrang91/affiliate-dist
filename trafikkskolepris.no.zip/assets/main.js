/* trafikkskolepris.no – minimal vanilla JS. Ingen eksterne biblioteker. */
(function () {
  'use strict';

  // 1) Byvelger: sender brukeren til riktig byside
  document.querySelectorAll('form[data-city-search]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var sel = form.querySelector('select');
      if (sel && sel.value) { window.location.href = '/trafikkskoler/' + sel.value + '/'; }
    });
  });

  // 2) Tilbudsskjema: IKKE koblet til backend ennå.
  //    TODO (eier): koble til skjema-backend (f.eks. egen endpoint, Formspark, Netlify Forms)
  //    og fjern blokkeringen under. Vis aldri falsk "sendt"-melding.
  document.querySelectorAll('form[data-lead-form]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var note = form.querySelector('[data-lead-notice]');
      if (!form.checkValidity()) { form.reportValidity(); return; }
      if (note) {
        note.hidden = false;
        note.focus();
      }
    });
  });

  // 3) Kalkulator på /hva-koster-forerkort/
  var calc = document.querySelector('[data-calc]');
  if (calc) {
    var fmt = function (n) { return Math.round(n).toLocaleString('nb-NO') + ' kr'; };
    var val = function (name) {
      var el = calc.querySelector('[name="' + name + '"]');
      if (!el) return 0;
      if (el.type === 'checkbox') return el.checked;
      var n = parseFloat(String(el.value).replace(/\s/g, '').replace(',', '.'));
      return isNaN(n) ? 0 : n;
    };
    var update = function () {
      var lessons = val('lessons');
      var rate = val('rate');
      var pkg = val('package');
      var tg = val('tg');
      var online = val('online');
      var fees = online ? (480 + 1490 + 160 + 100) : (480 + 1540 + 270 + 100);
      var lessonCost = lessons * rate;
      var total = lessonCost + pkg + tg + fees;
      calc.querySelector('[data-out="lessons"]').textContent = lessons;
      calc.querySelector('[data-out="total"]').textContent = fmt(total);
      calc.querySelector('[data-out="breakdown"]').textContent =
        'Kjøretimer ' + fmt(lessonCost) + ' + obligatorisk opplæring ' + fmt(pkg) +
        ' + trafikalt grunnkurs ' + fmt(tg) + ' + offentlige gebyrer ' + fmt(fees);
    };
    calc.addEventListener('input', update);
    calc.addEventListener('change', update);
    update();
  }
})();

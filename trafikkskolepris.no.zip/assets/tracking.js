/* Samtykkebanner og egne hendelser for Trafikkskolepris.no.
   GTM og consent-standard ligger inline i <head> på hver side. */
(function(){
  var KEY = 'tsp_consent';
  window.dataLayer = window.dataLayer || [];
  function gtag(){ dataLayer.push(arguments); }
  var saved = null; try { saved = localStorage.getItem(KEY); } catch(e){}

  /* Felles funksjon for egne hendelser */
  window.tspTrack = function(event, params){ dataLayer.push(Object.assign({event:event}, params||{})); };

  /* Samtykkebanner */
  function setConsent(v){
    try{ localStorage.setItem(KEY, v); }catch(e){}
    var g = v==='all' ? 'granted' : 'denied';
    gtag('consent','update',{ad_storage:g,ad_user_data:g,ad_personalization:g,analytics_storage:g});
    window.tspTrack('consent_choice',{consent:v});
    var b=document.getElementById('tsp-consent'); if(b) b.remove();
  }
  function banner(){
    if(saved) return;
    var d=document.createElement('div'); d.id='tsp-consent'; d.setAttribute('role','dialog'); d.setAttribute('aria-label','Informasjonskapsler');
    d.innerHTML='<p>Vi bruker informasjonskapsler til statistikk, slik at vi ser hvilke byer og skoler folk sammenligner. Ingenting brukes før du godtar.</p>'+
      '<div><button type="button" data-c="necessary">Bare nødvendige</button><button type="button" data-c="all" class="primary">Godta statistikk</button></div>';
    d.addEventListener('click',function(e){ var c=e.target.getAttribute('data-c'); if(c) setConsent(c); });
    document.body.appendChild(d);
  }
  window.tspConsent = function(){ try{ localStorage.removeItem(KEY); }catch(e){} saved=null; banner(); };
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',banner); else banner();
})();

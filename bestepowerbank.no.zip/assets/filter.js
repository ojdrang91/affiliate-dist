/* Filtrering og sortering av produktkort: <form class="filters" data-grid="id"> med <select data-f="nøkkel" data-m="min|max|eq"> og <input type=checkbox data-f data-m="flag">. */
(function () {
  document.querySelectorAll('form.filters').forEach(function (f) {
    var grid = document.getElementById(f.dataset.grid);
    if (!grid) return;
    var cards = [].slice.call(grid.children), count = f.querySelector('.count');
    function num(c, k) { return parseFloat(c.dataset[k] || '0') || 0; }
    function run() {
      var shown = 0;
      cards.forEach(function (c) {
        var ok = true;
        f.querySelectorAll('[data-f]').forEach(function (el) {
          var k = el.dataset.f, m = el.dataset.m;
          if (m === 'flag') { if (el.checked && !c.dataset[k]) ok = false; return; }
          var v = el.value; if (!v) return;
          if (m === 'min' && num(c, k) < parseFloat(v)) ok = false;
          if (m === 'max' && num(c, k) > parseFloat(v)) ok = false;
          if (m === 'eq' && (c.dataset[k] || '') !== v) ok = false;
        });
        c.hidden = !ok; if (ok) shown++;
      });
      var s = f.querySelector('[data-sort]').value, dir = s[0] === '-' ? -1 : 1, key = s.replace('-', '');
      cards.slice().sort(function (a, b) { return (num(a, key) - num(b, key)) * dir; }).forEach(function (c) { grid.appendChild(c); });
      if (count) count.textContent = shown + ' av ' + cards.length + ' vises';
    }
    f.addEventListener('change', run); run();
  });
})();

// godsnakk.no – meny, innholdsfortegnelse og strømkalkulator (ingen data sendes noe sted)
(function () {
  var btn = document.querySelector('.nav-toggle');
  var nav = document.getElementById('meny');
  if (btn && nav) {
    btn.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && nav.classList.contains('open')) {
        nav.classList.remove('open');
        btn.setAttribute('aria-expanded', 'false');
        btn.focus();
      }
    });
  }

  // Marker aktiv seksjon i innholdsfortegnelsen
  var tocLinks = document.querySelectorAll('.toc a');
  if (tocLinks.length && 'IntersectionObserver' in window) {
    var map = {};
    tocLinks.forEach(function (a) { map[a.getAttribute('href').slice(1)] = a; });
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting && map[en.target.id]) {
          tocLinks.forEach(function (a) { a.classList.remove('active'); });
          map[en.target.id].classList.add('active');
        }
      });
    }, { rootMargin: '0px 0px -70% 0px' });
    Object.keys(map).forEach(function (id) { var el = document.getElementById(id); if (el) io.observe(el); });
  }

  var form = document.getElementById('stromkalk');
  if (!form) return;
  var out = document.getElementById('calc-out');
  var nf = new Intl.NumberFormat('nb-NO', { maximumFractionDigits: 0 });
  function v(id) { var n = parseFloat(String(document.getElementById(id).value).replace(',', '.')); return isNaN(n) ? 0 : n; }
  function calc() {
    var kwh = v('kwh');
    var pasl = kwh * (v('p1') - v('p2')) / 100;      // øre -> kr
    var fast = 12 * (v('m1') - v('m2'));
    var sum = pasl + fast;
    var head = sum >= 0 ? 'Du kan spare' : 'Den nye avtalen blir dyrere med';
    out.innerHTML = head + '<strong>' + nf.format(Math.abs(sum)) + ' kr i året</strong>' +
      '<span class="meta">Påslag: ' + nf.format(pasl) + ' kr · Månedsbeløp: ' + nf.format(fast) + ' kr</span>';
  }
  form.addEventListener('input', calc);
  calc();
})();

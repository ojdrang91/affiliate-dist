/* bestetv.no – størrelsesvelger, veiviser med anbefaling, filtre, sammenligning og størrelseskalkulator. Ingen sporing, ingen informasjonskapsler. */
(function () {
  const nf = new Intl.NumberFormat('nb-NO');
  const kr = (v) => nf.format(Math.round(v)) + ' kr';
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const COLORS = window.PANEL_COLORS || {};
  const SLUGS = window.PANEL_SLUGS || {};
  const PT = window.PANEL_SCORES || {};
  const IMG_ERR = "this.parentNode.classList.add('empty');this.remove()";

  /* ---------- Størrelsesvelger på produktkort (alle sider) ---------- */
  document.addEventListener('click', (e) => {
    const b = e.target.closest('.sizes button'); if (!b) return;
    const box = b.parentNode, card = box.closest('.tv'), d = JSON.parse(box.dataset.sizes)[+b.dataset.i];
    box.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
    card.querySelector('[data-pr]').textContent = kr(d.pr);
    card.querySelector('[data-w]').textContent = `Lavest hos ${d.shop}${d.k > 1 ? ` · ${d.k} butikker` : ''}`;
    card.querySelector('[data-s]').textContent = `${d.s}"`;
    const go = card.querySelector('[data-go]'); go.href = `/go/${d.go}`; go.firstChild.textContent = `Til ${d.shop} `;
    const pic = card.querySelector('.pic');
    if (d.img) { pic.classList.remove('empty'); pic.innerHTML = `<img src="${esc(d.img)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="${IMG_ERR}">`; }
    const c = card.querySelector('[data-cmp]');
    if (c && d.id != null) { c.dataset.cmp = d.id; const on = window.__cmpHas && window.__cmpHas(d.id); c.setAttribute('aria-pressed', String(!!on)); c.textContent = on ? '✓ Valgt' : 'Sammenlign'; }
  });

  /* ---------- Størrelseskalkulator ---------- */
  const calc = document.getElementById('calc');
  if (calc) {
    const r = calc.querySelector('input'), out = calc.querySelector('output'), txt = calc.querySelector('[data-txt]');
    const STD = [43, 50, 55, 65, 75, 85, 98];
    const upd = () => {
      const m = +r.value, lo = Math.round(m * 100 / 2.54 / 1.6), hi = Math.round(m * 100 / 2.54 / 1.2);
      const fit = STD.filter((s) => s >= lo - 3 && s <= hi + 3);
      out.textContent = `${lo}–${hi} tommer`;
      txt.innerHTML = `På ${nf.format(m)} meter passer <b>${fit.length ? (fit.length > 1 ? fit.slice(0, -1).join(', ') + ' eller ' + fit[fit.length - 1] : fit[0]) + ' tommer' : 'en stor skjerm'}</b>. ` +
        (fit.length ? 'Se TV-er i ' + fit.filter((s) => s < 98).map((s) => `<a href="/storrelse/${s}-tommer/">${s}"</a>`).join(', ') + '.' : '');
    };
    r.addEventListener('input', upd); upd();
  }

  /* ---------- Veiviser (forsiden) ---------- */
  const root = document.getElementById('finn');
  if (!root) return;
  document.documentElement.classList.add('js');
  const SIZE = { '2': [43, 55], '3': [55, 77], '4': [75, 100] };
  const KEYS = ['room', 'use', 'dist'];
  const q = { room: null, use: null, dist: null };
  const st = { max: 0, sort: 'price', show: 12, cmp: [], step: 0, all: false };
  let TVS = [];
  const quality = (t) => { const s = PT[t.p] || {}; return (s.svart || 0) + (s.lys || 0) + (s.farge || 0) + (s.gaming || 0); };

  fetch('/assets/tv.json').then((r) => r.json()).then((d) => { TVS = d; TVS.forEach((t, i) => (t.id = i)); index(); update(); })
    .catch(() => { root.querySelector('[data-rec]').innerHTML = '<p>Kunne ikke laste TV-listen. Prøv å laste siden på nytt.</p>'; });

  /* Steg for steg */
  const steps = [...root.querySelectorAll('.step')];
  function go(i) {
    st.step = Math.max(0, Math.min(i, steps.length));
    steps.forEach((s, j) => s.classList.toggle('on', j === st.step));
    const done = st.step >= steps.length;
    root.classList.toggle('done', done);
    root.querySelector('[data-stepno]').textContent = done ? 'Ferdig' : `Steg ${st.step + 1} av ${steps.length}`;
    root.querySelector('[data-bar]').style.width = `${(Math.min(st.step, steps.length) / steps.length) * 100}%`;
    root.querySelector('[data-back]').hidden = st.step === 0;
    root.querySelector('[data-skip]').hidden = done;
    root.querySelector('[data-reset]').hidden = !done && !Object.values(q).some(Boolean);
  }
  root.querySelectorAll('.pick').forEach((g) => g.addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    q[g.dataset.q] = b.dataset.v;
    g.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
    update();
    go(KEYS.indexOf(g.dataset.q) + 1);
    if (st.step >= steps.length) root.querySelector('[data-rec]').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }));
  root.querySelector('[data-back]').addEventListener('click', () => go(st.step - 1));
  root.querySelector('[data-skip]').addEventListener('click', () => go(st.step + 1));
  root.querySelector('[data-reset]').addEventListener('click', () => {
    KEYS.forEach((k) => (q[k] = null)); root.querySelectorAll('.pick button').forEach((x) => x.setAttribute('aria-pressed', 'false')); update(); go(0);
  });
  go(0);

  const sel = (n) => root.querySelector(`[name=${n}]`);
  sel('max').addEventListener('change', (e) => { st.max = +e.target.value; st.show = 12; update(); });
  sel('sort').addEventListener('change', (e) => { st.sort = e.target.value; render(); });
  root.querySelector('[data-more]').addEventListener('click', () => { st.show += 12; render(); });
  root.querySelector('[data-showall]').addEventListener('click', (e) => { st.all = true; e.target.hidden = true; root.querySelector('[data-all]').hidden = false; render(); });

  /* Råd ut fra svarene */
  function advice() {
    const { room, use, dist } = q, why = [];
    let panels = ['Mini LED', 'QLED', 'OLED', 'QNED', 'QD-OLED'];
    if (room === 'lyst') { panels = ['Mini LED', 'QLED', 'QNED']; why.push('en lys stue krever høy lysstyrke, og <a href="/skjermtyper/mini-led/">Mini LED</a> er sterkest'); }
    if (room === 'mork') { panels = ['OLED', 'QD-OLED', 'Mini LED']; why.push('i et mørkt rom gir <a href="/skjermtyper/oled/">OLED</a> perfekt svart'); }
    if (room === 'begge') { panels = ['Mini LED', 'OLED', 'QD-OLED']; why.push('når lyset varierer, er <a href="/sammenlign/mini-led-vs-oled/">Mini LED og OLED</a> de trygge valgene'); }
    if (use === 'film' && !room) { panels = ['OLED', 'QD-OLED', 'Mini LED']; why.push('til film er kontrast viktigst'); }
    if (use === 'vanlig' && !room) { panels = ['QLED', 'LED', 'QNED', 'Mini LED']; why.push('til vanlig TV holder en rimelig QLED'); }
    if (use === 'gaming' && !room) { panels = ['OLED', 'Mini LED', 'QD-OLED']; }
    if (use === 'gaming') why.push('til gaming bør du ha <a href="/forklart/hdmi-2-1/">120 Hz og HDMI 2.1</a>');
    if (use === 'sport') why.push('til sport gir <a href="/forklart/hz/">100/120 Hz</a> jevnere bevegelser');
    if (dist) why.push({ '2': 'under 2 meter passer 43–55 tommer', '3': '2–3 meter passer 55–77 tommer', '4': 'over 3 meter passer 75 tommer eller mer' }[dist]);
    const sizes = SIZE[dist] || [55, 65];
    return { panels, sizes, hz: use === 'gaming' || use === 'sport', why, answered: Object.values(q).some(Boolean) };
  }

  function filtered(a, ignoreSize) {
    return TVS.filter((t) => a.panels.includes(t.p) && (ignoreSize || (t.s >= a.sizes[0] && t.s <= a.sizes[1])) &&
      (!st.max || t.min <= st.max) && (!a.hz || !t.hz || t.hz >= 100));
  }

  /* Tre konkrete forslag: budsjett, best for pengene, premium */
  function picks(a) {
    const C = filtered(a).filter((t) => t.o[0].st).sort((x, y) => x.min - y.min);
    if (!C.length) return [];
    const used = new Set(), out = [];
    const take = (t, label, why) => { if (!t) return; used.add(t.f || t.id); out.push({ t, label, why }); };
    const free = (t) => !used.has(t.f || t.id);
    const strong = (t) => !a.hz || (t.hz && t.hz >= 100) || t.h21;
    const budget = C.find((t) => free(t) && strong(t)) || C[0];
    take(budget, 'Budsjett', `Den rimeligste ${budget.p}-TV-en i ${budget.s}" som passer svarene dine.`);
    const prim = a.panels[0];
    const median = C[Math.floor(C.length / 2)].min;
    const value = C.find((t) => free(t) && t.p === prim && strong(t) && t.min >= budget.min) || C.find((t) => free(t) && quality(t) > quality(budget) && t.min <= median);
    if (value) {
      const extra = [value.hz ? `${value.hz} Hz` : '', value.h21 ? 'HDMI 2.1' : ''].filter(Boolean).join(' og ');
      take(value, 'Best for pengene', `${value.p} passer best til svarene dine, og dette er den rimeligste vi finner i ${value.s}"${extra ? ` med ${extra}` : ''}.`);
    }
    const qmax = Math.max(...C.filter(free).map(quality));
    const top = C.filter((t) => free(t) && quality(t) === qmax);
    const prem = top.find((t) => t.h21 || (t.hz && t.hz >= 120)) || top[0];
    if (prem) take(prem, 'Premium', `Beste bildekvalitet blant valgene: ${prem.p}${prem.h21 ? ' med HDMI 2.1' : ''}.`);
    return out;
  }

  function famSizes(t, a) {
    if (!t.f) return [];
    return TVS.filter((x) => x.f === t.f && x.p === t.p && x.o[0].st && (!st.max || x.min <= st.max)).sort((x, y) => x.s - y.s);
  }

  function card(t, a, label, why) {
    const o = t.o[0], on = st.cmp.includes(t.id), fam = famSizes(t, a);
    const sizes = fam.length > 1 ? `<div class="sizes" role="group" aria-label="Størrelse" data-sizes="${esc(JSON.stringify(fam.map((x) => ({ id: x.id, s: x.s, pr: x.min, shop: x.o[0].shop, k: x.o.length, go: x.o[0].go, img: x.img || '' }))))}">${fam.map((x, i) => `<button type="button" data-i="${i}" aria-pressed="${x.id === t.id}">${x.s}"</button>`).join('')}</div>` : '';
    const spec = [`<span data-s>${t.s}"</span>`, `<a class="pt" href="/skjermtyper/${SLUGS[t.p] || ''}/"><i></i>${esc(t.p)}</a>`, t.r ? esc(t.r) : '', t.hz ? `${t.hz} Hz` : '', t.h21 ? 'HDMI 2.1' : ''].filter(Boolean).join(' · ');
    return `<article class="tv${label ? ' pickcard' : ''}" style="--pc:${COLORS[t.p] || '#888'}">
      ${label ? `<span class="badge">${label}</span>` : ''}
      <div class="pic${t.img ? '' : ' empty'}" data-b="${esc(t.b)}">${t.img ? `<img src="${esc(t.img)}" alt="${esc(t.n)}" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="${IMG_ERR}">` : ''}</div>
      <div class="tvb"><h3 title="${esc(t.n)}">${esc(t.t || t.n)}</h3><p class="spec">${spec}</p>${why ? `<p class="why">${why}</p>` : ''}${sizes}
      <div class="price" data-pr>${kr(o.pr)}</div>
      <p class="where" data-w>Lavest hos ${esc(o.shop)}${t.o.length > 1 ? ` · ${t.o.length} butikker` : ''}${o.st ? '' : ' · <span class="no">ikke på lager</span>'}</p>
      <a class="go" data-go href="/go/${esc(o.go)}" rel="sponsored nofollow noopener" target="_blank">Til ${esc(o.shop)} <span aria-hidden="true">→</span></a>
      <button class="go alt" type="button" data-cmp="${t.id}" aria-pressed="${on}">${on ? '✓ Valgt' : 'Sammenlign'}</button></div>
    </article>`;
  }

  function update() { st.show = 12; renderRec(); render(); }

  function renderRec() {
    if (!TVS.length) return;
    const a = advice(), P = picks(a), box = root.querySelector('[data-rec]');
    const sz = `${a.sizes[0]}–${a.sizes[1] >= 100 ? '100' : a.sizes[1]}"`;
    const head = a.answered
      ? `Vi anbefaler <b>${esc(a.panels[0])}</b> i <b>${sz}</b>`
      : `Utgangspunkt for de fleste: <b>Mini LED</b> eller <b>QLED</b> i <b>55–65"</b>`;
    const why = a.why.length ? a.why.join(', ') : 'Svar på spørsmålene over, så tilpasser vi forslagene til rommet og bruken din';
    box.innerHTML = `<div class="verdict"><h3>${head}</h3><p>${why.charAt(0).toUpperCase() + why.slice(1)}.</p></div>` +
      (P.length ? `<div class="tvs picks">${P.map((x) => card(x.t, a, x.label, x.why)).join('')}</div>` : '<p>Ingen TV-er på lager passer alle valgene. Prøv en høyere makspris.</p>');
  }

  function list() {
    const a = advice();
    const L = filtered(a);
    const by = { price: (x, y) => x.min - y.min, size: (x, y) => y.s - x.s || x.min - y.min,
      fit: (x, y) => (a.panels.indexOf(x.p) - a.panels.indexOf(y.p)) || x.min - y.min }[st.sort];
    L.sort((x, y) => (y.o[0].st - x.o[0].st) || by(x, y));
    const seen = new Set();
    return L.filter((t) => { const k = t.f || 'id' + t.id; if (seen.has(k)) return false; seen.add(k); return true; });
  }

  const box = root.querySelector('[data-list]');
  root.addEventListener('click', (e) => { const b = e.target.closest('[data-cmp]'); if (b) toggle(+b.dataset.cmp); });
  function render() {
    if (!TVS.length) return;
    const L = list(), a = advice();
    root.querySelector('[data-showall]').textContent = `Se alle ${nf.format(L.length)} modeller som passer`;
    root.querySelector('[data-count]').textContent = `${nf.format(L.length)} modeller passer (av ${nf.format(TVS.length)} TV-er i oversikten)`;
    if (!st.all) { cmp(); return; }
    box.innerHTML = L.slice(0, st.show).map((t) => card(t, a)).join('') || '<p>Ingen TV-er passer alle valgene. Prøv en høyere makspris eller start på nytt.</p>';
    root.querySelector('[data-more]').hidden = L.length <= st.show;
    cmp();
  }
  window.__cmpHas = (id) => st.cmp.includes(id);
  function toggle(id) {
    const i = st.cmp.indexOf(id);
    if (i >= 0) st.cmp.splice(i, 1); else { if (st.cmp.length >= 3) st.cmp.shift(); st.cmp.push(id); }
    sync();
  }
  function sync() {
    root.querySelectorAll('[data-cmp]').forEach((b) => { const on = st.cmp.includes(+b.dataset.cmp); b.setAttribute('aria-pressed', String(on)); b.textContent = on ? '✓ Valgt' : 'Sammenlign'; });
    cmp();
  }

  function cmp() {
    const items = st.cmp.map((i) => TVS[i]), bar = document.getElementById('cmpbar'), sec = document.getElementById('cmp');
    bar.hidden = !items.length;
    bar.querySelector('span').textContent = items.length < 2 ? `${items.length} valgt – velg én til` : `${items.length} TV-er valgt`;
    sec.hidden = items.length < 2;
    if (items.length < 2) return;
    const best = (f, low) => { const v = items.map(f).filter((x) => x != null); return v.length ? (low ? Math.min(...v) : Math.max(...v)) : null; };
    const row = (l, f, w) => `<tr><th scope="row">${l}</th>${items.map((t) => `<td${w && w(t) ? ' class="win"' : ''}>${f(t)}</td>`).join('')}</tr>`;
    const mp = best((t) => t.min, true), mh = best((t) => t.hz), ms = best((t) => (PT[t.p] || {}).svart), ml = best((t) => (PT[t.p] || {}).lys);
    sec.querySelector('table').innerHTML = `<thead><tr><th></th>${items.map((t) => `<th>${esc(t.t || t.n)} ${t.s}"</th>`).join('')}</tr></thead><tbody>` +
      row('Skjermtype', (t) => `<a href="/skjermtyper/${SLUGS[t.p]}/">${esc(t.p)}</a>`) +
      row('Størrelse', (t) => `${t.s} tommer`) +
      row('Svart og kontrast', (t) => `${(PT[t.p] || {}).svart || '–'} av 5`, (t) => (PT[t.p] || {}).svart === ms) +
      row('Lysstyrke', (t) => `${(PT[t.p] || {}).lys || '–'} av 5`, (t) => (PT[t.p] || {}).lys === ml) +
      row('Oppdatering', (t) => (t.hz ? `${t.hz} Hz` : 'ikke oppgitt'), (t) => t.hz && t.hz === mh) +
      row('HDMI 2.1', (t) => (t.h21 ? 'Ja' : 'ikke oppgitt')) +
      row('Laveste pris', (t) => kr(t.min), (t) => t.min === mp) +
      row('Butikker', (t) => t.o.map((o) => `<a href="/go/${esc(o.go)}" rel="sponsored nofollow noopener" target="_blank">${esc(o.shop)}</a> <span class="num">${kr(o.pr)}</span>${o.st ? '' : ' (ikke på lager)'}`).join('<br>')) +
      '</tbody>';
  }
  document.getElementById('cmpbar').querySelector('button').addEventListener('click', () => document.getElementById('cmp').scrollIntoView({ behavior: 'smooth', block: 'start' }));
  document.getElementById('cmp').querySelector('[data-clear]').addEventListener('click', () => { st.cmp = []; sync(); });

  /* Lim inn lenke fra butikk */
  const norm = (u) => { try { const x = new URL(u.trim()); return (x.hostname.replace(/^www\./, '') + x.pathname).replace(/\/$/, '').toLowerCase(); } catch { return ''; } };
  let byUrl = null;
  function index() { byUrl = new Map(); TVS.forEach((t) => t.o.forEach((o) => o.u && byUrl.set(norm(o.u), t.id))); }
  root.querySelector('[data-paste]').addEventListener('submit', (e) => {
    e.preventDefault();
    const inp = e.target.querySelector('input'), msg = root.querySelector('[data-msg]'), k = norm(inp.value);
    let id = byUrl && byUrl.get(k);
    if (id == null && k) { const n = (k.match(/(\d{6,})/) || [])[1]; if (n) for (const [u, i] of byUrl) if (u.includes(n)) { id = i; break; } }
    if (id == null) { msg.textContent = k ? 'Fant ikke den TV-en. Vi har TV-er fra Komplett, CS Megastore, Proshop og Kjell & Co.' : 'Lim inn en hel lenke som starter med https://'; return; }
    if (!st.cmp.includes(id)) toggle(id);
    msg.textContent = `Lagt til i sammenligningen: ${TVS[id].t || TVS[id].n} ${TVS[id].s}"`;
  });
})();

const b=document.querySelector('[data-menu]');
const n=document.querySelector('[data-nav]');
if(b&&n){b.addEventListener('click',()=>{const o=n.classList.toggle('open');b.setAttribute('aria-expanded',o?'true':'false')});}
document.querySelectorAll('[data-nav] a').forEach(a=>a.addEventListener('click',()=>{if(n)n.classList.remove('open')}));

// Simple outbound affiliate click tracking. Works when GA4/gtag is present, does nothing otherwise.
document.querySelectorAll('[data-affiliate]').forEach(a=>a.addEventListener('click',()=>{
  if(typeof window.gtag==='function'){
    window.gtag('event','affiliate_click',{
      affiliate_partner:a.getAttribute('data-affiliate'),
      link_url:a.href
    });
  }
}));

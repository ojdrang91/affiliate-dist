
const mb=document.querySelector('.menu-btn'),nav=document.querySelector('.main-nav');if(mb&&nav){mb.addEventListener('click',()=>{const o=nav.classList.toggle('open');mb.setAttribute('aria-expanded',String(o));});}
const filters=document.querySelectorAll('[data-filter]'),cards=document.querySelectorAll('.product-card');filters.forEach(b=>b.addEventListener('click',()=>{filters.forEach(x=>x.classList.remove('active'));b.classList.add('active');const f=b.dataset.filter;cards.forEach(c=>c.style.display=(f==='all'||c.dataset.cat===f)?'':'none');}));

document.querySelectorAll('img').forEach((img)=>{
  img.addEventListener('error',()=>{
    if(img.dataset.fallbackApplied) return;
    img.dataset.fallbackApplied='1';
    const box=document.createElement('div');
    box.className='image-fallback';
    box.innerHTML='<strong>Produktbilde</strong><span>Bildet kunne ikke lastes akkurat nå.</span>';
    img.replaceWith(box);
  });
});


document.querySelectorAll('a[rel~="sponsored"]').forEach((a)=>a.addEventListener('click',()=>{document.documentElement.classList.add('affiliate-clicked');}));


// Close mobile navigation after selecting a link and with Escape.
document.querySelectorAll('.main-nav a').forEach((a)=>a.addEventListener('click',()=>{if(nav){nav.classList.remove('open');if(mb)mb.setAttribute('aria-expanded','false');}}));
document.addEventListener('keydown',(e)=>{if(e.key==='Escape'&&nav&&nav.classList.contains('open')){nav.classList.remove('open');if(mb){mb.setAttribute('aria-expanded','false');mb.focus();}}});

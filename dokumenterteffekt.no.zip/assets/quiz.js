/* Veiviser «Hva passer for meg?». Kjører i nettleseren; svarene sendes ingen steder.
   Svarene lagres i URL-en (#mal=...&fisk=...) så resultatet kan deles. */
(function () {
  var root = document.getElementById("vv");
  if (!root) return;
  var DATA = JSON.parse(document.getElementById("vv-data").textContent);
  var P = {};
  DATA.pages.forEach(function (p) { P[p.slug] = p; });

  var Q = [
    { id: "mal", q: "Hva vil du helst ha hjelp med?", a: [
      ["trening", "Trening og styrke"], ["sovn", "Søvn og ro"], ["fokus", "Fokus og konsentrasjon"],
      ["grunnmur", "Generell helse – få i meg det jeg trenger"], ["levetid", "Holde meg ung og frisk lenger"]] },
    { id: "flagg", q: "Gjelder noe av dette deg?", hint: "Svaret avgjør om vi kan gi generelle råd i det hele tatt.", a: [
      ["nei", "Nei, ingenting av dette"], ["gravid", "Gravid eller ammer"], ["medisin", "Bruker legemidler fast"],
      ["sykdom", "Har en kronisk sykdom"], ["ung", "Er under 18 år"]] },
    { id: "fisk", q: "Hvor ofte spiser du fet fisk (laks, ørret, makrell, sild) eller tar tran?", a: [
      ["ofte", "Minst én gang i uka, eller tran daglig"], ["sjelden", "Sjelden eller aldri"]] },
    { id: "trening", q: "Hvor ofte trener du styrke eller harde intervaller?", a: [
      ["mye", "To ganger i uka eller mer"], ["litt", "Av og til"], ["nei", "Nesten aldri"]] },
    { id: "protein", q: "Synes du det er vanskelig å få nok protein fra maten?", a: [
      ["ja", "Ja, det er vanskelig"], ["nei", "Nei, jeg spiser kjøtt, fisk, egg eller meieri flere ganger daglig"]] },
    { id: "alder", q: "Hvor gammel er du?", a: [["18-74", "18–74 år"], ["75", "75 år eller eldre"]] }
  ];

  var ans = {}, step = 0;
  var elStep = root.querySelector("[data-step]"), elRes = root.querySelector("[data-result]");

  function readHash() {
    var h = location.hash.replace(/^#/, "");
    if (!h) return;
    h.split("&").forEach(function (kv) {
      var p = kv.split("="), q = Q.filter(function (x) { return x.id === p[0]; })[0];
      if (q && q.a.some(function (a) { return a[0] === p[1]; })) ans[p[0]] = p[1];
    });
  }
  function writeHash() {
    var s = Q.filter(function (q) { return ans[q.id]; }).map(function (q) { return q.id + "=" + ans[q.id]; }).join("&");
    history.replaceState(null, "", "#" + s);
  }
  function esc(s) { var d = document.createElement("div"); d.textContent = s; return d.innerHTML; }

  // Hopp over spørsmål som ikke trengs
  function needed(q) {
    if (q.id === "flagg" || q.id === "mal") return true;
    if (ans.flagg && ans.flagg !== "nei") return false;
    if (q.id === "protein") return ans.trening && ans.trening !== "nei";
    return true;
  }
  function nextIndex(i) { for (var j = i + 1; j < Q.length; j++) if (needed(Q[j])) return j; return Q.length; }
  function prevIndex(i) { for (var j = i - 1; j >= 0; j--) if (needed(Q[j])) return j; return -1; }

  function renderStep() {
    if (step >= Q.length) return renderResult();
    var q = Q[step], total = Q.filter(needed).length, pos = Q.slice(0, step + 1).filter(needed).length;
    elRes.hidden = true; elStep.hidden = false;
    elStep.innerHTML =
      '<p class="vv-prog">Spørsmål ' + pos + " av " + total + "</p>" +
      '<fieldset><legend><h2 class="vv-q">' + esc(q.q) + "</h2></legend>" +
      (q.hint ? '<p class="vv-hint">' + esc(q.hint) + "</p>" : "") +
      q.a.map(function (a, i) {
        var id = "vv-" + q.id + "-" + i;
        return '<label class="vv-opt" for="' + id + '"><input type="radio" name="' + q.id + '" id="' + id + '" value="' + a[0] + '"' +
          (ans[q.id] === a[0] ? " checked" : "") + "> <span>" + esc(a[1]) + "</span></label>";
      }).join("") + "</fieldset>" +
      '<div class="vv-nav">' + (prevIndex(step) >= 0 ? '<button type="button" class="vv-back">Tilbake</button>' : "<span></span>") +
      '<button type="button" class="btn vv-next"' + (ans[q.id] ? "" : " disabled") + ">" +
      (nextIndex(step) >= Q.length ? "Vis resultat" : "Neste") + "</button></div>";
    elStep.querySelectorAll("input").forEach(function (inp) {
      inp.addEventListener("change", function () {
        ans[q.id] = this.value;
        elStep.querySelector(".vv-next").disabled = false;
      });
    });
    elStep.querySelector(".vv-next").addEventListener("click", function () { writeHash(); step = nextIndex(step); renderStep(); focusTop(); });
    var back = elStep.querySelector(".vv-back");
    if (back) back.addEventListener("click", function () { step = prevIndex(step); renderStep(); focusTop(); });
  }
  function focusTop() {
    var h = root.querySelector(elRes.hidden ? ".vv-q" : ".vv-res-h");
    if (h) { h.setAttribute("tabindex", "-1"); h.focus(); }
  }

  function item(slug, why) {
    var p = P[slug];
    return '<li><a href="/' + slug + '/"><strong>' + esc(p.name) + "</strong></a> " +
      '<span class="badge lv-' + p.level.toLowerCase() + '">' + esc(p.levelName) + "</span>" +
      '<span class="vv-dose">Dose i studier: ' + esc(p.dose) + (p.price ? " · " + esc(p.price) : "") + "</span>" +
      '<span class="vv-why">' + why + "</span></li>";
  }

  function decide() {
    var best = [], maybe = [], skip = [], a = ans;
    if (a.fisk === "sjelden") {
      best.push(["d-vitamin", "Du spiser sjelden fet fisk eller tran. Da får mange i Norge for lite D-vitamin, særlig om vinteren." +
        (a.alder === "75" ? " Fra 75 år er anbefalt inntak høyere (20 µg)." : "")]);
      maybe.push(["omega-3", "Du spiser sjelden fet fisk. Omega-3 fra tran, kapsler eller algeolje dekker EPA og DHA."]);
    } else if (a.fisk === "ofte") {
      skip.push(["omega-3", "Du spiser fet fisk eller tar tran, og får trolig nok omega-3 allerede."]);
      if (a.alder === "75") maybe.push(["d-vitamin", "Fra 75 år er anbefalt inntak 20 µg. Sjekk om tran eller fisk dekker det."]);
    }
    if (a.trening === "mye") best.push(["kreatin", "Du trener styrke eller intervaller jevnlig. Kreatin monohydrat er det best dokumenterte tilskuddet for det – og et av de billigste."]);
    if (a.trening === "litt") maybe.push(["kreatin", "Du trener av og til. Kreatin virker, men gir mest når du trener jevnlig."]);
    if (a.protein === "ja") maybe.push(["proteinpulver", "Du synes det er vanskelig å få nok protein. Pulver er en praktisk måte å fylle hullet på – maten først."]);
    if (a.mal === "trening" && a.trening && a.trening !== "nei")
      maybe.push(["pre-workout", "Koffein er det som faktisk virker i en pre-workout. En kopp kaffe gjør mye av samme jobb."]);
    if (a.mal === "sovn") {
      maybe.push(["magnesium", "Magnesium virker mot mangel, men dokumentasjonen for bedre søvn hos folk uten mangel er svak."]);
      maybe.push(["l-teanin", "L-teanin kan gi litt ro, men studiene er få og små. Prøv i noen uker og se om du merker forskjell."]);
    }
    if (a.mal === "fokus") maybe.push(["l-teanin", "Best dokumentert sammen med koffein (f.eks. kaffe eller te), alene er effekten usikker."]);
    if (a.mal === "levetid") {
      skip.push(["nad-nmn-nr", "Ingen studier på mennesker viser at NAD+-tilskudd gjør deg yngre eller friskere. NMN er ikke godkjent i Norge."]);
      skip.push(["nac", "For friske er dokumentasjonen svak. NAC er også et legemiddel og bør ikke tas uten grunn."]);
    }
    if (a.mal === "grunnmur" && a.fisk === "ofte")
      maybe.push(["magnesium", "Variert kost dekker magnesium for de fleste. Tilskudd gir mest mening ved påvist mangel."]);
    // Fjern dubletter, behold første (sterkeste) plassering
    var seen = {};
    function uniq(list) { return list.filter(function (x) { if (seen[x[0]]) return false; seen[x[0]] = 1; return true; }); }
    best = uniq(best); maybe = uniq(maybe); skip = uniq(skip);
    return { best: best, maybe: maybe, skip: skip };
  }

  function renderResult() {
    elStep.hidden = true; elRes.hidden = false;
    var out = '<h2 class="vv-res-h">Ditt resultat</h2>';
    if (ans.flagg && ans.flagg !== "nei") {
      var why = { gravid: "er gravid eller ammer", medisin: "bruker legemidler", sykdom: "har en kronisk sykdom", ung: "er under 18 år" }[ans.flagg];
      out += '<div class="warn"><p><strong>Snakk med lege, helsestasjon eller apotek først.</strong> Når du ' + esc(why) +
        ", kan kosttilskudd påvirke behandling eller ha andre anbefalte doser. Derfor gir vi ingen generelle forslag her.</p></div>" +
        '<p>Du kan likevel lese om hvert tilskudd i <a href="/#tilskudd">oversikten</a>, der står det også hvem som bør være forsiktig.</p>';
    } else {
      var r = decide();
      if (r.best.length) out += '<h3>Best dokumentert for deg</h3><ul class="vv-list">' + r.best.map(function (x) { return item(x[0], x[1]); }).join("") + "</ul>";
      if (r.maybe.length) out += '<h3>Kan vurderes</h3><ul class="vv-list">' + r.maybe.map(function (x) { return item(x[0], x[1]); }).join("") + "</ul>";
      if (r.skip.length) out += '<h3>Kan du trolig droppe</h3><ul class="vv-list">' + r.skip.map(function (x) { return item(x[0], x[1]); }).join("") + "</ul>";
      if (!r.best.length && !r.maybe.length)
        out += "<p>Ut fra svarene dine ser det ikke ut til at du trenger kosttilskudd. Variert kost dekker det meste for de fleste.</p>";
      out += '<p class="vv-note">Resultatet bygger på evidensnivåene og dosene på sidene våre, og er generell informasjon – ikke medisinske råd. ' +
        'Prøv gjerne én ting av gangen, så vet du hva som eventuelt virker. <a href="/metode/">Slik vurderer vi</a>.</p>';
    }
    out += '<div class="vv-nav"><button type="button" class="vv-restart">Start på nytt</button>' +
      '<button type="button" class="btn vv-share">Kopier lenke til resultatet</button></div><p class="vv-shared" aria-live="polite"></p>';
    elRes.innerHTML = out;
    elRes.querySelector(".vv-restart").addEventListener("click", function () {
      ans = {}; history.replaceState(null, "", location.pathname); step = 0; renderStep(); focusTop();
    });
    elRes.querySelector(".vv-share").addEventListener("click", function () {
      var msg = elRes.querySelector(".vv-shared");
      try {
        navigator.clipboard.writeText(location.href).then(function () { msg.textContent = "Lenken er kopiert."; },
          function () { msg.textContent = location.href; });
      } catch (e) { msg.textContent = location.href; }
    });
  }

  readHash();
  var complete = Q.every(function (q) { return !needed(q) || ans[q.id]; });
  step = complete && ans.mal ? Q.length : 0;
  renderStep();
})();

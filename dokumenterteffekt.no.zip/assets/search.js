/* Dokumentert effekt – søk i nettleseren. Indeksen ligger i /assets/search-index.json. */
(function () {
  var idx = null, loading = null;
  function norm(s) {
    return (s || "").toLowerCase()
      .replace(/æ/g, "ae").replace(/ø/g, "o").replace(/å/g, "a")
      .normalize("NFD").replace(/[̀-ͯ]/g, "")
      .replace(/[^a-z0-9+ ]+/g, " ").replace(/\s+/g, " ").trim();
  }
  function load() {
    if (idx) return Promise.resolve(idx);
    if (!loading) {
      loading = fetch("/assets/search-index.json").then(function (r) { return r.json(); }).then(function (d) {
        idx = d.map(function (it) {
          it._t = norm(it.t); it._k = norm(it.k + " " + (it.c || []).join(" ")); it._d = norm(it.d); return it;
        });
        return idx;
      }).catch(function () { idx = []; return idx; });
    }
    return loading;
  }
  // enkel avstand for skrivefeil («magnisium», «kreattin»)
  function close(a, b) {
    if (Math.abs(a.length - b.length) > 2) return false;
    var m = a.length, n = b.length, p = [], i, j;
    for (j = 0; j <= n; j++) p[j] = j;
    for (i = 1; i <= m; i++) {
      var prev = p[0]; p[0] = i;
      for (j = 1; j <= n; j++) {
        var tmp = p[j];
        p[j] = Math.min(p[j] + 1, p[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
        prev = tmp;
      }
    }
    return p[n] <= (a.length > 6 ? 2 : 1);
  }
  function score(it, terms) {
    var s = 0;
    for (var i = 0; i < terms.length; i++) {
      var t = terms[i], hit = 0;
      if (it._t.indexOf(t) === 0) hit = 10;
      else if (it._t.indexOf(t) > -1) hit = 7;
      else if (it._k.indexOf(t) > -1) hit = 5;
      else if (it._d.indexOf(t) > -1) hit = 2;
      else if (t.length > 3) {
        var words = (it._t + " " + it._k).split(" ");
        for (var w = 0; w < words.length; w++) { if (close(t, words[w])) { hit = 3; break; } }
      }
      if (!hit) return 0;
      s += hit;
    }
    return s;
  }
  function esc(s) { return s.replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  function setup(box) {
    var input = box.querySelector("input"), list = box.querySelector(".search-results"), active = -1, results = [];
    function close_() { list.hidden = true; input.setAttribute("aria-expanded", "false"); active = -1; }
    function render(q) {
      var terms = norm(q).split(" ").filter(Boolean);
      if (!terms.length) { close_(); return; }
      var prio = { "Tilskudd": 3, "Sammenligning": 2, "Produkt": 1, "Avsnitt": 0 };
      results = idx.map(function (it) { return [score(it, terms) * 10 + (prio[it.y] || 0), it]; })
        .filter(function (x) { return x[0] >= 10; })
        .sort(function (a, b) { return b[0] - a[0]; }).slice(0, 8).map(function (x) { return x[1]; });
      if (!results.length) {
        list.innerHTML = '<li class="r-empty">Ingen treff på «' + esc(q) + '». Prøv et annet ord, f.eks. «søvn» eller «trening».</li>';
      } else {
        list.innerHTML = results.map(function (it, i) {
          var lv = it.l ? ' <span class="badge lv-' + { Sterk: "a", Moderat: "b", Svak: "c", Utilstrekkelig: "d" }[it.l] + '">' + esc(it.l) + "</span>" : "";
          var cov = it.c ? '<span class="r-c">' + it.c.map(function (n) { return "<span>" + esc(n) + "</span>"; }).join("") + "</span>" : "";
          var typ = it.y ? '<span class="r-y">' + esc(it.y) + "</span>" : "";
          return '<li role="option" id="' + list.id + "-" + i + '" aria-selected="false"><a href="' + it.u + '">' + typ + '<span class="r-t">' + esc(it.t) + lv + '</span><span class="r-d">' + esc(it.d) + "</span>" + cov + "</a></li>";
        }).join("");
      }
      active = -1; list.hidden = false; input.setAttribute("aria-expanded", "true");
    }
    function mark() {
      var items = list.querySelectorAll("[role=option]");
      for (var i = 0; i < items.length; i++) items[i].setAttribute("aria-selected", i === active ? "true" : "false");
      if (active > -1 && items[active]) { input.setAttribute("aria-activedescendant", items[active].id); items[active].scrollIntoView({ block: "nearest" }); }
      else input.removeAttribute("aria-activedescendant");
    }
    input.addEventListener("focus", load);
    input.addEventListener("input", function () { var q = input.value; load().then(function () { render(q); }); });
    input.addEventListener("keydown", function (ev) {
      if (ev.key === "ArrowDown" && results.length) { active = Math.min(active + 1, results.length - 1); mark(); ev.preventDefault(); }
      else if (ev.key === "ArrowUp" && results.length) { active = Math.max(active - 1, 0); mark(); ev.preventDefault(); }
      else if (ev.key === "Enter") {
        var target = results[active > -1 ? active : 0];
        if (target) { location.href = target.u; ev.preventDefault(); }
      } else if (ev.key === "Escape") { close_(); }
    });
    document.addEventListener("click", function (ev) { if (!box.contains(ev.target)) close_(); });
  }
  var boxes = document.querySelectorAll("[data-search]");
  for (var i = 0; i < boxes.length; i++) setup(boxes[i]);
})();

/* Filtrer kortene på forsiden etter mål. */
(function () {
  var chips = document.querySelectorAll(".chip"), cards = document.querySelectorAll("[data-cards] .card");
  for (var i = 0; i < chips.length; i++) {
    chips[i].addEventListener("click", function () {
      var g = this.getAttribute("data-goal");
      for (var j = 0; j < chips.length; j++) {
        var on = chips[j] === this;
        chips[j].classList.toggle("is-on", on);
        chips[j].setAttribute("aria-pressed", on ? "true" : "false");
      }
      for (var k = 0; k < cards.length; k++) {
        var goals = cards[k].getAttribute("data-goals").split(" ");
        cards[k].hidden = g !== "alle" && goals.indexOf(g) === -1;
      }
    });
  }
})();
/* «Finn etter formål»-lenkene velger riktig fane i tilskuddslisten. */
(function () {
  var links = document.querySelectorAll("[data-goal-link]");
  for (var i = 0; i < links.length; i++) {
    links[i].addEventListener("click", function () {
      var chip = document.querySelector('.chip[data-goal="' + this.getAttribute("data-goal-link") + '"]');
      if (chip) chip.click();
    });
  }
})();

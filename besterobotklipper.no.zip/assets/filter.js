(function () {
  var buttons = Array.from(document.querySelectorAll('.filter'));
  var cards = Array.from(document.querySelectorAll('#modelcards .product-card'));
  if (!buttons.length || !cards.length) return;
  buttons.forEach(function (button) {
    button.addEventListener('click', function () {
      buttons.forEach(function (x) { x.classList.remove('active'); });
      button.classList.add('active');
      var f = button.getAttribute('data-filter');
      cards.forEach(function (card) {
        var area = Number(card.getAttribute('data-area') || 0);
        var nav = (card.getAttribute('data-nav') || '').toLowerCase();
        var drive = (card.getAttribute('data-drive') || '').toLowerCase();
        var show = f === 'all' ||
          (f === 'small' && area <= 600) ||
          (f === 'mid' && area >= 800 && area <= 1500) ||
          (f === 'large' && area >= 2000) ||
          (f === 'awd' && (drive.indexOf('allhjul') >= 0 || drive.indexOf('awd') >= 0)) ||
          (f === 'lidar' && nav.indexOf('lidar') >= 0);
        card.hidden = !show;
      });
    });
  });
})();
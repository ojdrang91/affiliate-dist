/* Veiviser + modellfilter på forsiden */
(function () {
  var MODELS = [
    {n:"MOVA ViAX 300",s:"mova-viax-300",a:300,sl:0,nav:"vision",navL:"Kamera / AI vision",slL:"Ikke oppgitt",p:4990,i:"https://www.kjell.com/cdn-cgi/image/width=700,height=700,fit=pad,format=auto/globalassets/productimages/936330_66365_01.webp?ref=C6202056DE",t:"Budsjettvalg til liten plen"},
    {n:"MOVA ViAX 600",s:"mova-viax-600",a:600,sl:0,nav:"lidar",navL:"360° LiDAR + to AI-kameraer",slL:"Ikke oppgitt",p:5990,i:"https://www.kjell.com/cdn-cgi/image/width=700,height=700,fit=pad,format=auto/globalassets/productimages/937274_66729_01.webp?ref=86C5AF69EB",t:"Trær og smale passasjer"},
    {n:"Segway Navimow i105E",s:"segway-navimow-i105e",a:500,sl:30,nav:"rtk",navL:"RTK + VisionFence",slL:"30 %",p:10037,i:"https://csdam.net/data/jpg/0/fb9d95a2/fb9d95a2-d190-4589-8e07-b9c7f0876461.jpg",t:"Liten, åpen plen"},
    {n:"Segway Navimow i206E AWD",s:"segway-navimow-i206e-awd",a:600,sl:45,nav:"rtk",navL:"NRTK + vision",slL:"opptil 45 %",p:11967,i:"https://csdam.net/data/jpg/0/ed863d38/ed863d38-4638-46d0-8365-961b23c480a2.jpg",t:"AWD til kupert mellomplen"},
    {n:"Segway Navimow i208E AWD",s:"segway-navimow-i208e-awd",a:800,sl:45,nav:"rtk",navL:"NRTK + VisionFence",slL:"opptil 45 %",p:13499,i:"https://www.kjell.com/cdn-cgi/image/width=700,height=700,fit=pad,format=auto/globalassets/productimages/931283_66692_12.webp?ref=0F52AC30ED",t:"Sterk i bakke"},
    {n:"Segway Navimow i210E LiDAR Pro",s:"segway-navimow-i210e-lidar-pro",a:1000,sl:55,nav:"lidar",navL:"LiDAR + NetRTK + vision",slL:"opptil 55 %",p:19397,i:"https://csdam.net/data/jpg/0/7bfd3cd1/7bfd3cd1-6e99-4f3d-9fe0-557ed0eaf0e4.jpg",t:"Premium til krevende 1000 m²"},
    {n:"Segway Navimow i215 LiDAR",s:"segway-navimow-i215-lidar",a:1500,sl:45,nav:"lidar",navL:"LiDAR + vision",slL:"opptil 45 %",p:16769,i:"https://csdam.net/data/jpg/0/fcc7000b/fcc7000b-9c14-479a-b7e6-b709370b273d.jpg",t:"LiDAR til stor plen"},
    {n:"Mammotion LUBA mini 2 AWD 1000",s:"mammotion-luba-mini-2-awd-1000",a:1000,sl:80,nav:"vision",navL:"Tri-Camera AI + NetRTK",slL:"opptil 80 %",p:17266,i:"https://csdam.net/data/jpg/0/fc8beda3/fc8beda3-2b07-41f9-9c13-1932a0f90bc5.jpg",t:"Ekstrem helning"},
    {n:"Roborock RockNeo Q110",s:"roborock-rockneo-q110",a:1000,sl:45,nav:"rtk",navL:"RTK + VSLAM",slL:"opptil 45 %",p:14147,i:"https://garden-files.roborock.com/frontend-static/assets/products/rockneo-q1-v2/section1_KV.31f9b755.jpg",t:"Ny 1000 m²-utfordrer"},
    {n:"Eufy E15",s:"eufy-e15",a:800,sl:40,nav:"vision",navL:"Kamera / V-FSD",slL:"opptil 40 %",p:11490,i:"https://www.kjell.com/cdn-cgi/image/width=700,height=700,fit=pad,format=auto/globalassets/productimages/934869_66751_01.webp?ref=26A0206B0F",t:"Enkel vision-modell"},
    {n:"Eufy E18",s:"eufy-e18",a:1200,sl:40,nav:"vision",navL:"Kamera / V-FSD",slL:"opptil 40 %",p:12490,i:"https://www.kjell.com/cdn-cgi/image/width=700,height=700,fit=pad,format=auto/globalassets/productimages/934864_66750_01.webp?ref=F9ED3BBA6F",t:"Vision til 1200 m²"},
    {n:"Dreame A1 Pro 2000",s:"dreame-a1-pro",a:2000,sl:0,nav:"lidar",navL:"OmniSense 3D / LiDAR",slL:"Ikke oppgitt",p:11814,i:"https://csdam.net/data/jpg/0/eecc2a6b/eecc2a6b-03cb-4e2f-a655-bc32e59285a5.jpg",t:"LiDAR til stor plen"},
    {n:"Dreame A2 3000",s:"dreame-a2",a:3000,sl:50,nav:"lidar",navL:"OmniSense 2.0 + HDR-kamera",slL:"opptil 26,5°",p:19990,i:"https://www.kjell.com/cdn-cgi/image/width=700,height=700,fit=pad,format=auto/globalassets/productimages/911083_66313.webp?ref=AC56D1D378",t:"Store eiendommer"},
    {n:"Dreame A3 AWD 1000",s:"dreame-a3-awd",a:1000,sl:80,nav:"lidar",navL:"3D LiDAR / OmniSense 3.0",slL:"opptil 80 %",p:24890,i:"https://i.computersalg.dk/digitalcontent/0/6836/68363376.jpg",t:"LiDAR + AWD"}
  ];

  var SIZES = [
    {id:"s",label:"Under 300 m²",note:"Forhage eller rekkehustomt",need:300},
    {id:"m",label:"300–800 m²",note:"Vanlig norsk villaplen",need:800},
    {id:"l",label:"800–1500 m²",note:"Stor plen, gjerne oppdelt",need:1500},
    {id:"xl",label:"Over 1500 m²",note:"Småbruk eller stor eiendom",need:2500}
  ];
  var SLOPES = [
    {id:"flat",label:"Nesten flatt",note:"Under 15 % (ca. 9°)",need:0},
    {id:"mild",label:"Litt skrånende",note:"15–30 % (9–17°)",need:30},
    {id:"steep",label:"Tydelig bakke",note:"30–45 % (17–24°)",need:45},
    {id:"extreme",label:"Bratt",note:"Over 45 %",need:55}
  ];
  var SKY = [
    {id:"open",label:"Åpen himmel",note:"Få trær, lave bygg",pref:"rtk"},
    {id:"some",label:"Noen trær",note:"Enkelte skyggepartier",pref:"any"},
    {id:"dense",label:"Tett tredekke",note:"Løvverk, høye vegger, smale ganger",pref:"lidar"}
  ];

  var kr = function (v) { return v.toLocaleString("nb-NO").replace(/\u00a0/g, " ") + " kr"; };
  var m2 = function (v) { return v.toLocaleString("nb-NO").replace(/\u00a0/g, " ") + " m²"; };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c]; }); };

  var state = {size:null, slope:null, sky:null};

  function renderOpts(id, list, key) {
    var el = document.getElementById(id);
    if (!el) return;
    el.innerHTML = list.map(function (o) {
      return '<button type="button" class="opt' + (state[key] === o.id ? ' active' : '') + '" data-id="' + o.id + '"><b>' + esc(o.label) + '</b><span>' + esc(o.note) + '</span></button>';
    }).join("");
    Array.prototype.forEach.call(el.querySelectorAll("button"), function (b) {
      b.onclick = function () { state[key] = b.getAttribute("data-id"); renderWizard(); };
    });
  }

  function reason(m, s, sl, sk) {
    var parts = [], margin = Math.round((m.a / s.need - 1) * 100);
    if (margin >= 15) parts.push("Har " + margin + " % arealmargin over plenen din, som gir rom for soner og hindringer");
    else if (margin >= 0) parts.push("Dekker arealet, men uten stor margin hvis plenen er oppdelt");
    else parts.push("Ligger litt under oppgitt behov — aktuell bare hvis du har målt nøyaktig");
    if (sl.need > 0) {
      if (m.sl >= sl.need) parts.push("takler bakken din med " + m.slL.toLowerCase());
      else if (m.sl === 0) parts.push("helning er ikke dokumentert av produsenten");
    }
    if (sk.pref === "lidar" && m.nav === "lidar") parts.push("LiDAR gjør den mindre sårbar for signalskygge under trærne");
    else if (sk.pref === "lidar" && m.nav === "vision") parts.push("kamerabasert navigasjon klarer seg uten fri himmel");
    else if (sk.pref === "rtk" && m.nav === "rtk") parts.push("RTK er presist når plenen er åpen");
    else parts.push(m.navL + " som navigasjon");
    return parts.join(". ") + ".";
  }

  function renderWizard() {
    renderOpts("opt-size", SIZES, "size");
    renderOpts("opt-slope", SLOPES, "slope");
    renderOpts("opt-sky", SKY, "sky");
    var answered = ["size","slope","sky"].filter(function (k) { return state[k]; }).length;
    var prog = document.getElementById("progress");
    var box = document.getElementById("wresult");
    if (answered < 3) {
      prog.textContent = answered + " av 3 besvart";
      box.hidden = true;
      return;
    }
    prog.textContent = "Alle tre besvart — forslagene står under.";
    var s = SIZES.filter(function (x) { return x.id === state.size; })[0];
    var sl = SLOPES.filter(function (x) { return x.id === state.slope; })[0];
    var sk = SKY.filter(function (x) { return x.id === state.sky; })[0];

    var scored = MODELS.map(function (m) {
      var score = 0, fit = m.a / s.need;
      if (fit < 1) score -= 40 * (1 - fit); else score += Math.max(0, 14 - (fit - 1) * 16);
      if (sl.need > 0) {
        if (m.sl === 0) score -= 22;
        else if (m.sl < sl.need) score -= 30;
        else score += 12 - Math.min(10, (m.sl - sl.need) / 6);
      }
      if (sk.pref === "lidar") score += m.nav === "lidar" ? 16 : (m.nav === "vision" ? 6 : -18);
      if (sk.pref === "rtk") score += m.nav === "rtk" ? 8 : 2;
      if (sk.pref === "any") score += 4;
      return {m:m, score:score};
    }).sort(function (a, b) { return b.score - a.score; }).slice(0, 3);

    document.getElementById("verdict").innerHTML = "Plen på " + esc(s.label.toLowerCase()) + ", " + esc(sl.label.toLowerCase()) + " og " + esc(sk.label.toLowerCase()) +
      ". Da er <strong>" + esc(scored[0].m.n) + "</strong> det nærmeste treffet blant modellene vi følger" +
      (sk.pref === "lidar" ? ", fordi tredekket gjør ren satellittnavigasjon ustabil." : ".");

    document.getElementById("wcards").innerHTML = scored.map(function (x) {
      var m = x.m, url = "/modeller/" + m.s + "/";
      return '<article class="product-card featured">' +
        '<a class="product-media" href="' + url + '"><img src="' + m.i + '" alt="' + esc(m.n) + '" width="720" height="720" loading="lazy" decoding="async"></a>' +
        '<div class="product-body"><div class="kicker">' + esc(m.t) + '</div><h3><a href="' + url + '">' + esc(m.n) + '</a></h3>' +
        '<p>' + esc(reason(m, s, sl, sk)) + '</p>' +
        '<div class="meters">' +
          '<div class="meter"><span>Kapasitet</span><span>' + m2(m.a) + '</span></div><div class="bar"><i style="width:' + Math.min(100, Math.round(m.a / 30)) + '%"></i></div>' +
          '<div class="meter"><span>Maks helning</span><span>' + esc(m.slL) + '</span></div><div class="bar"><i class="gold" style="width:' + (m.sl ? Math.min(100, Math.round(m.sl * 1.25)) : 6) + '%"></i></div>' +
        '</div>' +
        '<div class="card-bottom"><div><span class="muted small">Registrert pris</span><strong>' + kr(m.p) + '</strong></div><a class="text-link" href="' + url + '">Les vurdering →</a></div>' +
        '</div></article>';
    }).join("");
    box.hidden = false;
  }

  var AREA_F = [
    {id:"all",label:"Alle"},
    {id:"a1",label:"Til 500 m²",t:function(m){return m.a<=500;}},
    {id:"a2",label:"500–1000 m²",t:function(m){return m.a>500&&m.a<=1000;}},
    {id:"a3",label:"Over 1000 m²",t:function(m){return m.a>1000;}}
  ];
  var NAV_F = [
    {id:"all",label:"Alle"},
    {id:"lidar",label:"LiDAR",t:function(m){return m.nav==="lidar";}},
    {id:"rtk",label:"RTK",t:function(m){return m.nav==="rtk";}},
    {id:"vision",label:"Kamera",t:function(m){return m.nav==="vision";}}
  ];
  var SLOPE_F = [
    {id:"all",label:"Alle"},
    {id:"s1",label:"Dokumentert helning",t:function(m){return m.sl>0;}},
    {id:"s2",label:"45 % eller mer",t:function(m){return m.sl>=45;}}
  ];
  var PRICE_F = [
    {id:"all",label:"Alle"},
    {id:"p1",label:"Under 12 000",t:function(m){return m.p<12000;}},
    {id:"p2",label:"12–18 000",t:function(m){return m.p>=12000&&m.p<=18000;}},
    {id:"p3",label:"Over 18 000",t:function(m){return m.p>18000;}}
  ];
  var SORT_F = [{id:"price",label:"Pris"},{id:"area",label:"Areal"},{id:"slope",label:"Helning"}];
  var f = {area:"all", nav:"all", slope:"all", price:"all", sort:"price"};

  function renderChips(id, list, key) {
    var el = document.getElementById(id);
    if (!el) return;
    el.innerHTML = list.map(function (o) {
      return '<button type="button" class="filter' + (f[key] === o.id ? ' active' : '') + '" data-id="' + o.id + '">' + esc(o.label) + '</button>';
    }).join("");
    Array.prototype.forEach.call(el.querySelectorAll("button"), function (b) {
      b.onclick = function () { f[key] = b.getAttribute("data-id"); renderGrid(); };
    });
  }

  function pass(list, id) {
    var x = list.filter(function (o) { return o.id === id; })[0];
    return (!x || !x.t) ? function () { return true; } : x.t;
  }

  function renderGrid() {
    renderChips("f-area", AREA_F, "area");
    renderChips("f-nav", NAV_F, "nav");
    renderChips("f-slope", SLOPE_F, "slope");
    renderChips("f-price", PRICE_F, "price");
    renderChips("f-sort", SORT_F, "sort");
    var out = MODELS.filter(function (m) {
      return pass(AREA_F, f.area)(m) && pass(NAV_F, f.nav)(m) && pass(SLOPE_F, f.slope)(m) && pass(PRICE_F, f.price)(m);
    });
    out.sort(function (a, b) { return f.sort === "area" ? b.a - a.a : f.sort === "slope" ? b.sl - a.sl : a.p - b.p; });
    document.getElementById("matchtext").textContent = out.length === MODELS.length ?
      "Viser alle " + MODELS.length + " modeller" : "Viser " + out.length + " av " + MODELS.length + " modeller";
    document.getElementById("nomatch").hidden = out.length > 0;
    document.getElementById("modelgrid").innerHTML = out.map(function (m) {
      var url = "/modeller/" + m.s + "/";
      return '<article class="product-card compact">' +
        '<a class="product-media" href="' + url + '"><img src="' + m.i + '" alt="' + esc(m.n) + '" width="720" height="720" loading="lazy" decoding="async"></a>' +
        '<div class="product-body"><h3><a href="' + url + '">' + esc(m.n) + '</a></h3>' +
        '<div class="spec-pills"><span>' + m2(m.a) + '</span><span>' + esc(m.navL) + '</span><span>' + esc(m.slL) + '</span></div>' +
        '<div class="card-bottom"><div><span class="muted small">Registrert pris</span><strong>' + kr(m.p) + '</strong></div><a class="text-link" href="' + url + '">Vurdering →</a></div>' +
        '</div></article>';
    }).join("");
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (!document.getElementById("modelgrid")) return;
    renderWizard();
    renderGrid();
    document.getElementById("wreset").onclick = function () { state = {size:null, slope:null, sky:null}; renderWizard(); };
    document.getElementById("fclear").onclick = function () { f = {area:"all", nav:"all", slope:"all", price:"all", sort:"price"}; renderGrid(); };
  });
})();

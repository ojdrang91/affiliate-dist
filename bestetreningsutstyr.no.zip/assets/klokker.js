/* Sammenligner for treningsklokker – data i window.KL (generert av tools/treningsklokker/generate.py) */
(function () {
  var K = window.KL; if (!K) return;
  var by = {}; K.data.forEach(function (d) { by[d.s] = d; });
  var sels = [].slice.call(document.querySelectorAll('.kl-picker select'));
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var kr = function (v) { return Math.round(v).toLocaleString('nb-NO').replace(/ /g, ' ') + ' kr'; };
  function fromUrl() {
    var m = new URLSearchParams(location.search).get('m');
    var l = (m ? m.split(',') : K.def).filter(function (s) { return by[s]; }).slice(0, 3);
    return l.length ? l : K.def;
  }
  function cell(v) {
    if (v === 'Ja') return '<span class="kl-yes">✓ Ja</span>';
    if (v === 'Nei') return '<span class="kl-no">– Nei</span>';
    if (v === 'Ikke oppgitt') return '<span class="kl-na">Ikke oppgitt</span>';
    return esc(v);
  }
  function render() {
    var pick = sels.map(function (s) { return s.value; }).filter(Boolean);
    var ms = pick.map(function (s) { return by[s]; });
    var cards = ms.map(function (d) {
      var img = d.img ? '<img src="' + esc(d.img) + '" alt="' + esc(d.n) + '" referrerpolicy="no-referrer" loading="lazy" onerror="this.onerror=null;this.src=\'/assets/product-placeholder.svg\'">' : '<img src="/assets/product-placeholder.svg" alt="">';
      var buy = d.go ? '<a class="btn block kl-buy" href="/go/' + d.go + '" rel="sponsored nofollow noopener" target="_blank">Kjøp nå – ' + kr(d.p) + '</a>'
        : '<p class="kl-out">Ikke på lager hos butikkene vi følger nå.</p>';
      var price = d.p ? '<span class="kl-price">Fra ' + kr(d.p) + '</span><span class="kl-where">hos ' + esc(d.shop) + '</span>' : '';
      return '<div class="card kl-vscard"><div class="kl-pimg">' + img + '</div><div class="kl-cb"><h2 class="kl-h3">' + esc(d.n) + '</h2><div class="kl-where">' + esc(d.l) + '</div><div class="kl-pl">' + price + '</div>' + buy +
        '<a class="kl-more" href="/treningsklokker/' + d.s + '/">Alt om ' + esc(d.sh) + ' →</a></div></div>';
    }).join('');
    document.getElementById('kl-cards').innerHTML = cards;
    if (!ms.length) { document.getElementById('kl-table').innerHTML = '<p class="sub">Velg minst én klokke.</p>'; return; }
    var head = '<tr><th></th>' + ms.map(function (d) { return '<th>' + esc(d.sh) + '</th>'; }).join('') + '</tr>';
    var rows = K.fields.map(function (f) {
      var vals = ms.map(function (d) { return d.f[f.k]; });
      var diff = ms.length > 1 && vals.some(function (v) { return v !== vals[0]; });
      return '<tr' + (diff ? ' class="kl-diff"' : '') + '><th scope="row">' + esc(f.l) + '</th>' + vals.map(function (v) { return '<td>' + cell(v) + '</td>'; }).join('') + '</tr>';
    }).join('');
    document.getElementById('kl-table').innerHTML = '<div class="kl-tablewrap"><table class="kl-spec"><thead>' + head + '</thead><tbody>' + rows + '</tbody></table></div>';
    var q = pick.join(',');
    history.replaceState(null, '', q ? '?m=' + q : location.pathname);
  }
  var init = fromUrl();
  sels.forEach(function (s, i) { s.value = init[i] || ''; s.addEventListener('change', render); });
  render();
  var b = document.getElementById('kl-share');
  if (b) b.addEventListener('click', function () {
    try { navigator.clipboard.writeText(location.href); b.textContent = 'Lenke kopiert'; } catch (e) { b.textContent = location.href; }
    setTimeout(function () { b.textContent = 'Kopier lenke til sammenligningen'; }, 2500);
  });
})();

(function(){
  var TAGS = {
    "FitNord Oceans 200":{mal:"kondisjon",plass:"middels",stille:true,niva:"lav",hvorfor:"Dette er en romaskin med lavt st\u00f8yniv\u00e5 og lav inngangspris."},
    "FitNord Sprint 300 G2":{mal:"kondisjon",plass:"stor",stille:false,niva:"mid",hvorfor:"L\u00f8ping hjemme krever b\u00e5de gulvplass og fri sone bak."},
    "FitNord Racer 200 G2":{mal:"kondisjon",plass:"liten",stille:true,niva:"ukjent",hvorfor:"En spinningsykkel tar lite plass og lager lite lyd."},
    "FitNord Cyclo 300":{mal:"kondisjon",plass:"liten",stille:true,niva:"ukjent",hvorfor:"En ergometersykkel er det mest nabovennlige kondisjonsvalget."},
    "Concept2 RowErg":{mal:"kondisjon",plass:"middels",stille:true,niva:"ukjent",hvorfor:"Dette er en romaskin med lang skinne, men lite lyd mot gulvet."},
    "JTC Power PRO 2 \u00d7 4\u201332,5 kg":{mal:"styrke",plass:"liten",stille:true,niva:"mid",hvorfor:"Dette er et helt manualsett p\u00e5 under \u00e9n kvadratmeter."},
    "FitNord Power Rack 500":{mal:"styrke",plass:"stor",stille:false,niva:"ukjent",hvorfor:"Et rack krever takh\u00f8yde, og vekter i gulvet merkes i etasjen under."},
    "FitNord Half Rack 500":{mal:"styrke",plass:"middels",stille:false,niva:"ukjent",hvorfor:"Et half rack har mindre fotavtrykk enn et fullt rack, men samme st\u00f8yhensyn."},
    "FitNord Home Gym 100":{mal:"styrke",plass:"middels",stille:true,niva:"ukjent",hvorfor:"Vektstabel i stedet for fri vekt gir lite slipplyd."},
    "FitNord Home Gym 200":{mal:"styrke",plass:"stor",stille:true,niva:"ukjent",hvorfor:"Apparatet gir flere \u00f8velser p\u00e5 samme plass, men tar mer gulv enn de minste modellene."}
  };
  var RANK={liten:1,middels:2,stor:3};
  var STEPS=[
    {key:"mal",q:"Hva vil du trene?",help:"Velg det du faktisk kommer til \u00e5 gj\u00f8re, ikke det du burde gj\u00f8re.",o:[["kondisjon","Kondisjon"],["styrke","Styrke"],["begge","Litt av begge"]]},
    {key:"plass",q:"Hvor mye gulvplass kan utstyret oppta?",help:"Regn med plassen rundt utstyret, ikke bare m\u00e5lene p\u00e5 apparatet.",o:[["liten","Under 2 m\u00b2"],["middels","2\u20134 m\u00b2"],["stor","Mer enn 4 m\u00b2"]]},
    {key:"naboer",q:"Bor du med naboer under deg?",help:"Avgj\u00f8r hvor mye st\u00f8y og vibrasjon utstyret kan lage.",o:[["ja","Ja, leilighet"],["nei","Nei, enebolig eller garasje"]]},
    {key:"budsjett",q:"Hva er budsjettet?",help:"Prisene under er sist registrerte pris der vi har den.",o:[["lav","Under 5 000 kr"],["mid","5 000\u201315 000 kr"],["hoy","Over 15 000 kr"]]}
  ];

  // Produktdata leses fra kortene i DOM, slik at HTML forblir kilden
  function produkter(){
    return [].slice.call(document.querySelectorAll('#cards article')).map(function(el){
      var h=el.querySelector('h3 a');
      var img=el.querySelector('img');
      var pris=el.querySelector('.price');
      var btn=el.querySelector('a.btn');
      return {navn:h?h.textContent.trim():'',rev:h?h.getAttribute('href'):'',img:img?img.getAttribute('src'):'',
              pris:pris?pris.textContent.trim():'',link:btn?btn.getAttribute('href'):'',aff:btn?btn.hasAttribute('rel'):false};
    });
  }

  function ogListe(l){ return l.length<2?(l[0]||''):l.slice(0,-1).join(', ')+' og '+l[l.length-1]; }

  var svar={},steg=0;
  var wz=document.getElementById('wz'),bar=document.getElementById('wz-bar'),cnt=document.getElementById('wz-count');

  function tegn(){
    if(!wz) return;
    bar.style.width=Math.round(Math.min(steg,STEPS.length)/STEPS.length*100)+'%';
    if(steg>=STEPS.length){ cnt.textContent='Ferdig'; resultat(); return; }
    cnt.textContent='Sp\u00f8rsm\u00e5l '+(steg+1)+' av '+STEPS.length;
    var s=STEPS[steg];
    var html='<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:28px;align-items:start"><div style="min-width:0">'+
      '<h3 style="font-size:clamp(21px,2.4vw,27px);font-weight:700;line-height:1.2">'+s.q+'</h3>'+
      '<p style="margin:10px 0 0;font-size:16px;color:var(--muted);max-width:42ch">'+s.help+'</p>'+
      (steg>0?'<button class="btn ghost" data-back style="margin-top:18px">\u2190 Forrige</button>':'')+
      '</div><div style="display:grid;gap:10px;min-width:0">'+
      s.o.map(function(o){return '<button class="chip" style="padding:16px 20px;min-height:56px;border-radius:14px;background:var(--card);font-size:16px;text-align:left" data-val="'+o[0]+'">'+o[1]+'</button>';}).join('')+
      '</div></div>';
    wz.innerHTML=html;
  }

  function resultat(){
    var liste=produkter().filter(function(p){return TAGS[p.navn];}).map(function(p){
      var t=TAGS[p.navn],score=0,g=[];
      if(svar.mal==='begge'||svar.mal===t.mal){score+=3;g.push(svar.mal==='begge'?'dekker '+t.mal:'passer m\u00e5let ditt om '+t.mal);}
      var d=RANK[t.plass]-RANK[svar.plass];
      if(d<=0){score+=5;g.push('f\u00e5r plass innenfor '+(svar.plass==='liten'?'under 2 m\u00b2':svar.plass==='middels'?'2\u20134 m\u00b2':'plassen du har'));}
      else if(d===1){score+=1;g.push('ligger i overkant av plassen du oppga');}
      else{score-=3;}
      if(svar.naboer==='ja'){ if(t.stille){score+=3;g.push('lager lite lyd mot etasjen under');} else {score-=4;g.push('kan bli for h\u00f8ylytt i leilighet');} }
      if(t.niva===svar.budsjett){score+=2;g.push('ligger i budsjettet du oppga');}
      else if(t.niva==='ukjent'){g.push('har ingen registrert dagpris hos oss');}
      return {p:p,score:score,tekst:t.hvorfor+' Den '+ogListe(g.slice(0,3))+'.'};
    }).filter(function(r){return r.score>0;}).sort(function(a,b){return b.score-a.score;}).slice(0,3);

    if(!liste.length){
      wz.innerHTML='<h3 style="font-size:21px;font-weight:700">Ingen av produktene vi har vurdert treffer svarene dine</h3>'+
      '<p style="margin:10px 0 18px;color:var(--muted);max-width:60ch">Det er et \u00e6rlig svar, ikke en feil. Beskriv rommet og hvor mange som skal bruke utstyret, s\u00e5 foresl\u00e5r vi noe konkret.</p>'+
      '<div style="display:flex;gap:10px;flex-wrap:wrap"><a class="btn" href="/kontakt/">F\u00e5 r\u00e5d</a><button class="btn ghost" data-restart>Start p\u00e5 nytt</button></div>';
      return;
    }
    wz.innerHTML='<h3 style="font-size:clamp(21px,2.4vw,27px);font-weight:700">Dette passer svarene dine</h3>'+
      '<p style="margin:10px 0 22px;color:var(--muted);max-width:62ch">Utvalget er begrenset til produktene vi har vurdert. Vi skriver hvorfor hvert forslag st\u00e5r her, slik at du kan v\u00e6re uenig.</p>'+
      '<div style="display:grid;gap:14px">'+liste.map(function(r){
        return '<div style="display:grid;grid-template-columns:'+(r.p.img?'auto ':'')+'minmax(0,1fr) auto;gap:18px;align-items:center;border:1px solid var(--line);border-radius:16px;padding:16px;background:#F9F6EF">'+
        (r.p.img?'<img src="'+r.p.img+'" alt="'+r.p.navn+'" loading="lazy" style="width:92px;height:92px;object-fit:contain;background:#fff;border-radius:12px;padding:8px">':'')+
        '<div style="min-width:0"><h4 style="font-family:\'Bricolage Grotesque\',sans-serif;font-size:18px;font-weight:700;margin:0"><a href="'+r.p.rev+'">'+r.p.navn+'</a></h4>'+
        '<p style="margin:6px 0 0;font-size:15px;color:var(--muted)">'+r.tekst+'</p>'+
        '<div class="price" style="margin-top:6px;font-weight:600">'+r.p.pris+'</div></div>'+
        '<a class="btn" href="'+r.p.link+'"'+(r.p.aff?' rel="sponsored nofollow" target="_blank"':'')+'>'+(r.p.aff?'Pris og tilgjengelighet':'Les vurderingen')+'</a></div>';
      }).join('')+'</div>'+
      '<button class="btn ghost" data-restart style="margin-top:20px">Start p\u00e5 nytt</button>';
  }

  if(wz){
    wz.addEventListener('click',function(e){
      var b=e.target.closest('button'); if(!b) return;
      if(b.hasAttribute('data-val')){ svar[STEPS[steg].key]=b.getAttribute('data-val'); steg++; tegn(); }
      else if(b.hasAttribute('data-back')){ steg=Math.max(0,steg-1); tegn(); }
      else if(b.hasAttribute('data-restart')){ steg=0; svar={}; tegn(); }
    });
    tegn();
  }

  // Omr\u00e5defilter
  var filters=document.getElementById('filters'),cards=document.getElementById('cards'),count=document.getElementById('count');
  function filtrer(v){
    var vist=0;
    [].forEach.call(cards.children,function(el){
      var match=(v==='Alle'||el.getAttribute('data-area')===v);
      el.hidden=!match; if(match) vist++;
    });
    [].forEach.call(filters.querySelectorAll('.chip'),function(c){c.setAttribute('aria-pressed',String(c.getAttribute('data-filter')===v));});
    count.textContent = v==='Alle'
      ? 'Produktene er valgt fordi de dekker forskjellige brukssituasjoner og prispunkter, ikke som \u00e9n samlet rangering. Viser alle '+vist+' valg.'
      : 'Viser '+vist+' valg for '+v.toLowerCase()+'.';
    history.replaceState(null,'',v==='Alle'?location.pathname+location.hash:'?omrade='+encodeURIComponent(v)+location.hash);
  }
  if(filters&&cards){
    filters.addEventListener('click',function(e){var b=e.target.closest('.chip'); if(b) filtrer(b.getAttribute('data-filter'));});
    document.addEventListener('click',function(e){var a=e.target.closest('[data-jump]'); if(a) filtrer(a.getAttribute('data-jump'));});
    var q=new URLSearchParams(location.search).get('omrade'); if(q) filtrer(q);
  }

  // Vis en tydelig placeholder hvis et produktbilde mangler
  [].forEach.call(document.images,function(img){
    var fallback=function(){
      if(img.src.indexOf('/assets/product-placeholder.svg')!==-1) return;
      img.removeEventListener('error',fallback);
      img.onerror=null;
      img.src='/assets/product-placeholder.svg';
      img.alt='Produktbilde mangler';
    };
    if(img.complete && img.naturalWidth===0) fallback();
    else img.addEventListener('error',fallback);
  });

  // Sticky kj\u00f8psknapp p\u00e5 vurderingssider
  var sticky=document.getElementById('sticky');
  if(sticky){
    var vis=function(){ sticky.style.transform = window.scrollY>700 ? 'translateY(0)' : 'translateY(110%)'; };
    window.addEventListener('scroll',vis,{passive:true}); vis();
  }
})();